package com.example.factorysimulation.models.nodes;

public class Connections {
    Node n1; Node n2;
    public Connections(Node n1, Node n2){
        this.n1 = n1;
        this.n2 = n2;
    }

    public Node getfirst() {
        return n1;
    }
    public Node getSecond() {
        return n2;
    }
}
