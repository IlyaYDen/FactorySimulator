package com.example.factorysimulation.models.nodes.stock;

import com.example.factorysimulation.models.nodes.providers.Provider;

public interface Stock {

    public Object getLock();

    int getDetailsSize();

    Provider[] getProviders();

    int getDetailsCount();
}
