package com.example.factorysimulation.models.nodes.controller;

public interface Controller {
}
