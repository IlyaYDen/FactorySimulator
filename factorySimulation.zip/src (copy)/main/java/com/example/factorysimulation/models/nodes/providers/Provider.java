package com.example.factorysimulation.models.nodes.providers;

import com.example.factorysimulation.models.details.DetailsEnum;
import com.example.factorysimulation.models.nodes.stock.DetailsStock;

public interface Provider {
   //Runnable start(DetailsStock detailsStock) throws InterruptedException;

   DetailsEnum getDetailType();

   Object getLock7();

   void setCons(DetailsStock detailsStock);
}
