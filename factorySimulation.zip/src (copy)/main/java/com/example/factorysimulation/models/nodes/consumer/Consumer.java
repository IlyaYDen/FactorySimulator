package com.example.factorysimulation.models.nodes.consumer;

public interface Consumer {
}
