package com.example.factorysimulation.models.nodes.constructor;

public interface Constructor {
}
