package com.example.factorysimulation.models.nodes.constructor;

import com.example.factorysimulation.models.details.Detail;
import com.example.factorysimulation.models.details.DetailsEnum;
import com.example.factorysimulation.models.nodes.Node;
import com.example.factorysimulation.models.nodes.NodeEnum;
import com.example.factorysimulation.models.nodes.providers.EngineProvider;
import com.example.factorysimulation.models.nodes.providers.Provider;
import com.example.factorysimulation.models.nodes.stock.DetailsStock;
import com.example.factorysimulation.models.nodes.stock.Gettable;
import com.example.factorysimulation.models.nodes.stock.Stock;

import java.util.*;
import java.util.concurrent.*;

public class CarConstructor extends Node implements Constructor, Provider, Gettable {
    DetailsStock[] detailsStocks;
    DetailsEnum[] de;
    DetailsEnum detailsEnum;
    final Object lock7 = 1;
    int time;
    Detail d = null;
    int workers;

    ArrayList<Detail> dl = new ArrayList<>();
  // DetailsStock detailsStock;
    Gettable detailsStock;
    public CarConstructor(DetailsStock[] detailsStocks, DetailsEnum[] de, int i, DetailsEnum type, int workers) {
        this.detailsStocks = detailsStocks;
        this.workers = workers;
        this.de = de;
        time = i;
        detailsEnum = type;
    }
    //public void start(DetailsStock detailsStock) {
    //    this.detailsStock = detailsStock;
    //}
/*
    public ExecutorService start(DetailsStock detailsStock, int workers) {
        this.detailsStock = detailsStock;
        ExecutorService tp = Executors.newFixedThreadPool(workers);
        for(int a = 0 ; a < workers ; a ++)
            tp.execute(this);
        return tp;
    }*/

    @Override
    public void run() {

                //System.out.println("worker " + Thread.currentThread().getName());
                synchronized (lock7) {
                    //System.out.println(detailsStock.limit + " " + detailsStock.getDetailsSize());
                    if (detailsStock.isNotFull()) {
                        try {

                            int a = 0;
                            FORBREAK:
                            for (DetailsStock ds : detailsStocks) {
                                synchronized (ds.lock2) {
                                    if (!ds.hasDetail()) {
                                        System.out.println("ПРОСИТ   " + ds.name + " " + ds.getDetailType().name());
                                        //System.out.println(ep.getDetailType().toString());
                                        ds.getNewDetails();
                                        ds.lock2.wait();
                                    }
                                    if (Arrays.stream(de).anyMatch(detailsEnum -> detailsEnum == ds.getDetailType())) {
                                        //FutureTask<Detail> df = new FutureTask(ds.getDetail());
                                        dl.add(ds.getDetail());//df.get());
                                    }
                                    DetailsEnum[] de2 = de.clone();
                                    for (Detail detail : dl){
                                        for (int f = 0; f < de2.length; f++) {
                                            if (de2[f] == detail.getType()) {
                                                de2[f] = null;
                                                a++;
                                            }
                                        }
                                    }
                                    if (a >= de.length) {
                                        ds.lock2.notifyAll();

                                        break FORBREAK;
                                    }
                                }
                            }
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }

                    }
                    else {
                        try {
                            while (!detailsStock.isNotFull())

                                lock7.wait();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
                if(Thread.currentThread().isInterrupted())
                    System.out.println("Interrupted");

                if(detailsStock.isNotFull(1)) {
                    System.out.println("МАШИНЫ: Added " + (detailsStock.getDetailsSize() + 1));
                    construct(dl);
                }
            }

    @Override
    public int getWorkers() {
        return 0;
    }

    private void construct(ArrayList<Detail> d) {
        try {
            //System.out.println();
            detailsStock.addStarted();
            System.out.println("СБОРКА: Начал собирать ласточку!" + Thread.currentThread().getName());
            //System.out.println();
            Thread.sleep(time);
            detailsStock.addDetail(new Detail(EngineProvider.id++,detailsEnum));
            dl.clear();
            //System.out.println();
            System.out.println("СБОРКА: Машина сделана!"  + Thread.currentThread().getName());
            detailsStock.removeStarted();
            //System.out.println();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public DetailsEnum getDetailType() {
        return detailsEnum;
    }

    @Override
    public Object getLock7() {
        return lock7;
    }

    @Override
    public void setCons(DetailsStock detailsStock) {
        this.detailsStock = detailsStock;
    }

    @Override
    public String getName() {
        return detailsEnum.name()+"Constructor";
    }

    @Override
    public boolean isNotFull() {
        return d == null && started==0;
    }

    public boolean isNotFull(int a ) {
        return isNotFull();
    }

    @Override
    public int getDetailsSize() {
        return d==null ? 0 : 1;
    }

    @Override
    public void addDetail(Detail detail) {
        d = detail;
    }

    final Object lock = 1;
    @Override
    public Detail getDetail() throws InterruptedException {

        synchronized (lock) {
            while (d==null) lock.wait();
            Detail det = d;
            d = null;

            for(Stock ep : detailsStocks) {
                synchronized (ep.getLock()) {
                    ep.getLock().notify();
                }
            }

            return det;
        }
    }

    int started = 0;
    @Override
    public void addStarted() {
        started++;
    }

    @Override
    public void removeStarted() {

    }

    @Override
    public Object getLock() {
        return lock;
    }

    public int getStarted(){
        return started;
    }


    @Override
    public NodeEnum getNodeName() {
        return NodeEnum.Constructor;
    }

    @Override
    public List<Detail> getDetails() {
        return dl;
    }

    @Override
    public List<Node> getInputNode() {
        List<Node> nlist = new ArrayList<>();
        for(Stock p : detailsStocks){
            nlist.add((Node) p);
        }
        return nlist;
    }
}
