package com.example.factorysimulation.models.nodes;

import com.example.factorysimulation.models.details.Detail;

import java.util.List;
import java.util.Timer;

public abstract class Node {
    abstract public NodeEnum getNodeName();
    abstract public List<Detail> getDetails();
    abstract public List<Node> getInputNode();
    abstract public void run();
    abstract public int getWorkers();

    double x;
    double y;
    public void setXY(double x,double y) {
        this.x = x;
        this.y = y;
    }
    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }

}
