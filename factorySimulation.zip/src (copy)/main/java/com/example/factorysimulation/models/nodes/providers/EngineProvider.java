package com.example.factorysimulation.models.nodes.providers;

import com.example.factorysimulation.models.details.Detail;
import com.example.factorysimulation.models.details.DetailsEnum;
import com.example.factorysimulation.models.nodes.Node;
import com.example.factorysimulation.models.nodes.NodeEnum;
import com.example.factorysimulation.models.nodes.stock.DetailsStock;
import com.example.factorysimulation.models.nodes.stock.Gettable;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class EngineProvider extends Node implements Provider, Runnable {

    public static volatile int id;
    final Object lock = new Object();
    DetailsEnum name;
    int delay;
    //DetailsStock detailsStock;
    Gettable getter;

    public EngineProvider(DetailsEnum s, int i) {
        name = s;
        delay = i;
    }

    @Override
    public Object getLock7(){
        return lock;
    }

    @Override
    public void setCons(DetailsStock detailsStock) {
        this.getter = detailsStock;
    }


    @Override
    public int getWorkers() {
        return 0;
    }
    Detail d = null;

    @Override
    public void run() {

        System.out.println(getter.getName() + " start");
        synchronized (lock) {
            d = new Detail(id++,name);
            //System.out.println(detailsStock.name + " Provider adding: " + detailsStock.getDetailType().toString());
            if (getter.isNotFull()) {
                //synchronized (detailsStock.lock2){
                //    detailsStock.lock2.notify();
                //}
            }
            else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        try {
            Thread.sleep(delay);
            System.out.println(getter.getName() + " added " + (getter.getDetailsSize()+1));
            getter.addDetail(d);
            d = null;
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        synchronized (getter.getLock()){
            getter.getLock().notify();
        }

        if(Thread.currentThread().isInterrupted())
            System.out.println("Interrupted");
    }

    //public void start(Gettable gettable) {
    //    //System.out.println(detailsStock.name + " EngineProvider starts: " + detailsStock.getDetailType().toString());
    //    this.getter = gettable;
    //    //Thread thread = new Thread(this);
    //    //thread.start();
    //}

    @Override
    public DetailsEnum getDetailType() {
        return name;
    }

    @Override
    public NodeEnum getNodeName() {
        return NodeEnum.Provider;
    }

    @Override
    public List<Detail> getDetails() {
        List<Detail> det = new ArrayList<>();
        if(d!=null)
            det.add(d);
        return det;
    }

    @Override
    public List<Node> getInputNode() {
        return null;
    }
}
