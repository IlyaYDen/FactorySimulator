package com.example.factorysimulation.view;

import com.example.factorysimulation.models.details.Detail;
import com.example.factorysimulation.models.nodes.Connections;
import com.example.factorysimulation.models.nodes.Node;
import javafx.event.ActionEvent;
import javafx.geometry.Orientation;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainView extends VBox {
    private Canvas canvas;
    int Screen = 800; //LifeGame.SIZE*SIZEX;
    List<Connections> con;
    List<Node> nodes;
    int nodeSize = 26;
    Button start;
    Button stop;
    public MainView(List<Node> nodes, List<Connections> con) {

        this.con = con;

        this.nodes = nodes;

        this.canvas = new Canvas(Screen,Screen+24);
        FlowPane ap = new FlowPane(Orientation.HORIZONTAL);

        start = new Button("Start");
        stop = new Button("Stop");
        ap.getChildren().addAll(this.start , this.stop);
        this.getChildren().addAll(this.canvas,ap);

        int b=1;
        for(int a = 0; a < nodes.size(); a++){
            nodes.get(a).setXY(b*12,40+(b*32*(2%b)));
            b++;
        }
        
        start.setOnAction(this::startSim);
        stop.setOnAction(this::stopSim);

        Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {

                draw();
            }
        },100,100);
        setOnMouseDragged(this::nodeDrag);
        setOnMouseClicked(this::nodeDragOver);

    }

    private void stopSim(ActionEvent actionEvent) {
        for(Timer t : timers)
            t.cancel();
        for(ExecutorService t : executorService)
            t.shutdownNow();
    }


    List<Timer> timers = new ArrayList<>();
    List<ExecutorService> executorService = new ArrayList<>();
    private void startSim(ActionEvent actionEvent) {

        for(Node n: nodes)
            if(n.getWorkers()<=1)
                timers.add(CreateChadulerForNode(n));
            else
                timers.add(CreateChadulerPoolForNode(n));
    }

    private Timer CreateChadulerPoolForNode(Node n) {
        int w = n.getWorkers();
        ExecutorService tp = Executors.newScheduledThreadPool(w);
        executorService.add(tp);

        Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                for(int a = 0 ; a < w ; a ++)
                    tp.execute(n::run);
            }
        },100,100);
        return t;
    }

    private Timer CreateChadulerForNode(Node n) {
        Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                n.run();
            }
        },100,100);
        return t;
    }


    boolean drag = false;
    private void nodeDragOver(MouseEvent mouseEvent) {
        drag = false;
        dragged = null;
        //System.out.println(drag + "  " + dragged);
    }

    double xdelt = 0;
    double ydelt = 0;
    Node dragged = null;
    private void nodeDrag(MouseEvent mouseEvent) {
        double x = mouseEvent.getX();
        double y = mouseEvent.getY();
        if(dragged == null && !drag)
            for(Node n : nodes){
                if( (n.getX()<=x && n.getX()+nodeSize>=x) && (n.getY()<=y && n.getY()+nodeSize>=y)){
                        drag=true;
                        xdelt = x-n.getX();
                        ydelt = y-n.getY();
                        dragged = n;
                    }
            }
        if(drag) {

            //System.out.println(x + " " + y);
            dragged.setXY(
                    (x - nodeSize / 2.), (y - nodeSize / 2.)
            );
            draw();
        }
    }

    private void draw() {
        GraphicsContext g = this.canvas.getGraphicsContext2D();

        g.clearRect(0, 0, Screen, Screen);

        g.setFill(Color.LIGHTBLUE);
        g.fillRect(0, 0, 2 * Screen, Screen * 2);


        g.setFill(Color.BLACK);
        for(int a = 0; a < nodes.size(); a++) {
            nodeDrawer(g,nodes.get(a));
        }
        g.setFill(Color.BLACK);
        for(Connections c: con){
            g.strokeLine(c.getfirst().getX()+(nodeSize/2.),c.getfirst().getY()+(nodeSize/2.),c.getSecond().getX()+(nodeSize/2.),c.getSecond().getY()+(nodeSize/2.));
        }
    }

    private void nodeDrawer(GraphicsContext g, Node node) {
        double nodeX = node.getX();
        double nodeY = node.getY();

        g.setFill(node.getNodeName().getColor());
        g.fillRect(nodeX, nodeY, nodeSize, nodeSize);
        int textl = (int) (nodeY+nodeSize+11);

        g.setFont(new Font(12));
        g.fillText(node.getNodeName().name(), nodeX, textl);
        textl+=12;

        if(node.getDetails()!=null) {
            g.fillText("Количество деталей: " + node.getDetails().size(), nodeX, textl);
            textl+=12;
            for(Detail d : node.getDetails()){
                g.fillText("Деталь: " + d.getType().name() + " ID: " + d.getId(), nodeX, textl);
                textl+=12;
            }
        }
    }

}
