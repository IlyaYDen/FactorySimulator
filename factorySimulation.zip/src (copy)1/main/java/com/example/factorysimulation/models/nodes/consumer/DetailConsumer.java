package com.example.factorysimulation.models.nodes.consumer;

import com.example.factorysimulation.models.details.Detail;
import com.example.factorysimulation.models.nodes.Node;
import com.example.factorysimulation.models.nodes.NodeEnum;
import com.example.factorysimulation.models.nodes.stock.Gettable;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DetailConsumer extends Node implements Consumer, Runnable {

    Gettable gettable;
    int delay;
    int workers;
    List<Detail> det = new ArrayList<>();
    public DetailConsumer(Gettable gettable, int delay, int workers) {
        this.gettable = gettable;
        this.delay = delay;
        this.workers = workers;
    }

    public ExecutorService start() {
        ExecutorService tp = Executors.newFixedThreadPool(workers);
        for(int a = 0 ; a < workers ; a ++)
            tp.execute(this);
        return tp;
    }

    @Override
    public void run() {

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    Thread.sleep(delay);
                    det.add(gettable.getDetail());
                    System.out.println("Consumer забрал ласточку " + gettable.getDetailsSize());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },100,100);
    }

    @Override
    public NodeEnum getNodeName() {
        return NodeEnum.Consumer;
    }

    @Override
    public List<Detail> getDetails() {
        return det;
    }

    @Override
    public List<Node> getInputNode() {
        List<Node> nlist = new ArrayList<>();
        nlist.add((Node)gettable);

        return nlist;
    }
}
