package com.example.factorysimulation.models.nodes.stock;

import com.example.factorysimulation.models.details.Detail;
import com.example.factorysimulation.models.details.DetailsEnum;
import com.example.factorysimulation.models.nodes.Node;
import com.example.factorysimulation.models.nodes.NodeEnum;
import com.example.factorysimulation.models.nodes.providers.EngineProvider;
import com.example.factorysimulation.models.nodes.providers.Provider;

import java.util.*;

public class DetailsStock extends Node implements Stock, Gettable {

    public int limit;
    //int delay;
    DetailsEnum detail;
    //ArrayList<Detail> details = new ArrayList<>();
    public String name;
    public /*static*/ final Object lock = 1;
    public final Object lock2 = 1;
    List<Detail> details =
            Collections.synchronizedList(new ArrayList<>());
    Provider[] engineProviders;


    //public DetailsStock(DetailsEnum detail, int i, int ii) {
    //    this.limit = i;
    //    this.delay = ii;
    //    this.detail = detail;
    //}

    public DetailsStock(String s, Provider[] providers, int limit) {
        name = s;
        this.engineProviders = providers;
        detail = engineProviders[0].getDetailType();
        this.limit = limit;
    }



    @Override
    public String getName() {
        return name;
    }

    public boolean isNotFull() {
        return (details.size() + started)<(limit);
    }
    public boolean isNotFull(int a ) {
        return (details.size() + started-a)<(limit);
    }
    public final Object lock7 = 1;

    public void addDetail(Detail detail) {
        details.add(detail);
        //synchronized (lock2) {
        //    lock2.notify();
        //}

    }
    public void getNewDetails(){
        for(Provider p : engineProviders)
            synchronized (p.getLock7()) {
                p.getLock7().notify();
            }
    }


    public Detail getDetail() throws InterruptedException {

        synchronized (lock) {
            while(details.size()==0)
                lock.wait();
            Detail dt = details.get(0);
            details.remove(dt);
            //for(Provider ep : engineProviders) {
            //    System.out.println(ep.getDetailType().toString());
            //    synchronized (ep.getLock7()) {
            //        ep.getLock7().notify();
            //    }
            //}
            return dt;
        }
    }

    //for(Provider ep : engineProviders)
    //    synchronized (ep.getLock7()) {
    //        ep.getLock7().notify();
    //    }
    public DetailsEnum getDetailType() {
        return detail;
    }

    public void start(String s) {
        name = s;
    }

    public boolean hasDetail() {
        return details.size()>0;
    }
    public int getDetailsSize(){
        return details.size();
    }

    @Override
    public Provider[] getProviders() {
        return engineProviders;
    }

    @Override
    public int getDetailsCount() {
        return details.size()+started;
    }

    int started = 0;
    @Override
    public void addStarted() {
        started++;
    }

    @Override
    public void removeStarted() {
        started--;
    }


    @Override
    public Object getLock() {
        return lock;
    }

    public int getStarted(){
        return started;
    }





    @Override
    public NodeEnum getNodeName() {
        return NodeEnum.Stock;
    }

    @Override
    public List<Detail> getDetails() {
        return details;
    }

    @Override
    public List<Node> getInputNode() {
        List<Node> nlist = new ArrayList<>();
        for(Provider p : engineProviders){
            nlist.add((Node) p);
        }
        return nlist;
    }
}
/*
        for(DetailsProvider<E> a : detailsProvider){
            ;
            System.out.println("DetailsStock for "+a.toString());
            Callable<E> c3 = a.start();

            Future<E> executionResult = threadPool.submit(c3);
            try {
                System.out.println(executionResult.get().getName());
            } catch (ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
 */
