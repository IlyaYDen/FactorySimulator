package com.example.factorysimulation.models.nodes.providers;

import com.example.factorysimulation.models.details.DetailsEnum;

public interface Provider {
   //Runnable start(DetailsStock detailsStock) throws InterruptedException;

   DetailsEnum getDetailType();

   Object getLock7();
}
