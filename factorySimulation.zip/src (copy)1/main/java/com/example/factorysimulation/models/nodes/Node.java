package com.example.factorysimulation.models.nodes;

import com.example.factorysimulation.models.details.Detail;
import javafx.scene.paint.Paint;

import java.util.List;

public abstract class Node {
    abstract public NodeEnum getNodeName();
    abstract public List<Detail> getDetails();
    abstract public List<Node> getInputNode();

    double x;
    double y;
    public void setXY(double x,double y) {
        this.x = x;
        this.y = y;
    }
    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }

}
