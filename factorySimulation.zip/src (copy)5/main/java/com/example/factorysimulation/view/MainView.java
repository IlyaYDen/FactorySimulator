package com.example.factorysimulation.view;

import javafx.scene.layout.VBox;

public class MainView extends VBox {

    public MainView() {



    }

}
