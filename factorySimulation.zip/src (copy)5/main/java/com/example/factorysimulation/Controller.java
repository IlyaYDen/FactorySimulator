package com.example.factorysimulation;

import com.example.factorysimulation.models.constructor.CarConstructor;
import com.example.factorysimulation.models.consumer.DetailConsumer;
import com.example.factorysimulation.models.controller.DetailController;
import com.example.factorysimulation.models.details.DetailsEnum;
import com.example.factorysimulation.models.prividers.EngineProvider;
import com.example.factorysimulation.models.prividers.Provider;
import com.example.factorysimulation.models.stock.DetailsStock;
import com.example.factorysimulation.view.MainView;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Controller extends Application {
    static final int SCREEN_SIZE_X = 800;
    static final int SCREEN_SIZE_Y = 820;
    static MainView mainView;
    @Override
    public void start(Stage stage) throws IOException {

        MainView mainView = new MainView();

        StackPane pane = new StackPane();
        pane.setAlignment(Pos.BOTTOM_CENTER);
        pane.getChildren().add(mainView);
        Scene scene = new Scene(pane,SCREEN_SIZE_X,SCREEN_SIZE_Y);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }



    public static void main(String[] args) {


        EngineProvider engineProvider = new EngineProvider( DetailsEnum.ENGINE,568);
        EngineProvider accessoryProvider = new EngineProvider(DetailsEnum.ACCESSORY,100);
        EngineProvider carcaseProvider = new EngineProvider(DetailsEnum.CARCASE,100);

        DetailsStock detailsStock1 = new DetailsStock("ПОСТАВЩИК ДВИГАТЕЛЕЙ: ",new Provider[]{engineProvider},1000);
        DetailsStock detailsStock2 = new DetailsStock("ПОСТАВЩИК АКСЕССУАРОВ: ",new Provider[]{accessoryProvider},1000);
        DetailsStock detailsStock3 = new DetailsStock("ПОСТАВЩИК КУЗОВОВ: ",new Provider[]{carcaseProvider},1000);

        CarConstructor carConstructor =
                new CarConstructor(
                        new DetailsStock[] {detailsStock1,detailsStock2,detailsStock3},
                        new DetailsEnum[] {DetailsEnum.ENGINE,DetailsEnum.ACCESSORY,DetailsEnum.CARCASE},300,DetailsEnum.CAR);

        DetailsStock detailsStock4 = new DetailsStock("МАШИНЫ: ",new Provider[]{carConstructor},4);

        DetailConsumer consumer = new DetailConsumer(detailsStock4, 1000,1);

        DetailController controller = new DetailController(detailsStock4, 5);


        consumer.getControlled()

        mainView = new MainView(MainView.makeConnections());


        try {
            carConstructor.start(detailsStock4,2);
            controller.start();

            engineProvider.start(detailsStock1);
            accessoryProvider.start(detailsStock2);
            carcaseProvider.start(detailsStock3);
            Thread.sleep(5000);
            consumer.start();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        launch();
    }

    public static void main1(String[] args) {
        //EngineStock<Engine> detailsStock = new EngineStock<Engine>(10, new EngineProvider());

        EngineProvider engineProvider1 = new EngineProvider( DetailsEnum.ENGINE,568);
        EngineProvider engineProvider2 = new EngineProvider( DetailsEnum.ENGINE,379);

        EngineProvider accessoryProvider = new EngineProvider(DetailsEnum.ACCESSORY,100);
        EngineProvider carcaseProvider = new EngineProvider(DetailsEnum.CARCASE,100);

        DetailsStock detailsStock1 = new DetailsStock("ПОСТАВЩИК ДВИГАТЕЛЕЙ: ",new Provider[]{engineProvider1,engineProvider2},1000);
        DetailsStock detailsStock2 = new DetailsStock("ПОСТАВЩИК АКСЕССУАРОВ: ",new Provider[]{accessoryProvider},1000);
        DetailsStock detailsStock3 = new DetailsStock("ПОСТАВЩИК КУЗОВОВ: ",new Provider[]{carcaseProvider},1000);

        CarConstructor carConstructor =
                new CarConstructor(
                        new DetailsStock[] {detailsStock1,detailsStock2,detailsStock3},
                        new DetailsEnum[] {DetailsEnum.ENGINE,DetailsEnum.ACCESSORY,DetailsEnum.CARCASE},300,DetailsEnum.CAR);

        DetailsStock detailsStock4 = new DetailsStock("МАШИНЫ: ",new Provider[]{carConstructor},4);

        DetailConsumer consumer = new DetailConsumer(detailsStock4, 1000,1);

        DetailController controller = new DetailController(detailsStock4, 5);

       // DetailConsumer consumer2 = new DetailConsumer(detailsStock1, 1000,1);

        // DetailController controller2 = new DetailController(detailsStock1, 5);

        try {
            carConstructor.start(detailsStock4,2);

            engineProvider1.start(detailsStock1);
            //consumer2.start();
            //controller2.start();
            engineProvider2.start(detailsStock1);
            accessoryProvider.start(detailsStock2);
            carcaseProvider.start(detailsStock3);
            Thread.sleep(5000);
            consumer.start();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        //launch();

    }
/*
    public static void createTimer(){
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                System.out.println("НА СКЛАДАХ ПОСТАВКА");
                for(int a = 0; a < 12*3; a+=3){
                    detailsStock1.addDetail(new Detail(a, DetailsEnum.ENGINE));
                    detailsStock2.addDetail(new Detail(a+1, DetailsEnum.ACCESSORY));
                    detailsStock3.addDetail(new Detail(a+2, DetailsEnum.CARCASE));
                }
            }
        },7000,7000);
    }
*/

}