package com.example.factorysimulation.models;

import com.example.factorysimulation.models.details.Detail;

public interface View {
    public Detail[] getDetails();
    public View[] getInput();
    public Models getModelType();
}
