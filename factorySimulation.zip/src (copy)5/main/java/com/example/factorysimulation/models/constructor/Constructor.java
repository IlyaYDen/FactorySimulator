package com.example.factorysimulation.models.constructor;

public interface Constructor {
}
