package com.example.factorysimulation.models.stock;

import com.example.factorysimulation.models.prividers.EngineProvider;
import com.example.factorysimulation.models.prividers.Provider;

public interface Stock {

    public Object getLock();

    int getDetailsSize();

    Provider[] getProviders();

    int getDetailsCount();
}
