package com.example.factorysimulation.models.controller;

public interface Controller {
}
