package com.example.factorysimulation.models.constructor;

import com.example.factorysimulation.models.details.Detail;
import com.example.factorysimulation.models.details.DetailsEnum;
import com.example.factorysimulation.models.prividers.EngineProvider;
import com.example.factorysimulation.models.prividers.Provider;
import com.example.factorysimulation.models.stock.DetailsStock;
import com.example.factorysimulation.models.stock.Gettable;
import com.example.factorysimulation.models.stock.Stock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.*;

public class CarConstructor implements Constructor, Runnable, Provider, Gettable, View {
    DetailsStock[] detailsStocks;
    DetailsEnum[] de;
    DetailsEnum detailsEnum;
    final Object lock7 = 1;
    int time;
    Detail d = null;

  // DetailsStock detailsStock;
    Gettable detailsStock;
    public CarConstructor(DetailsStock[] detailsStocks, DetailsEnum[] de, int i, DetailsEnum type) {
        this.detailsStocks = detailsStocks;
        this.de = de;
        time = i;
        detailsEnum = type;
    }

    public void start(DetailsStock detailsStock, int workers) {
        this.detailsStock = detailsStock;
        ExecutorService tp = Executors.newFixedThreadPool(workers);
        for(int a = 0 ; a < workers ; a ++)
            tp.execute(this);
    }

    @Override
    public void run() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {

                //System.out.println("worker " + Thread.currentThread().getName());
                ArrayList<Detail> d = new ArrayList<>();
                synchronized (lock7) {
                    //System.out.println(detailsStock.limit + " " + detailsStock.getDetailsSize());
                    if (detailsStock.isNotFull()) {
                        try {
                            FORBREAK:
                            for (DetailsStock ds : detailsStocks) {
                                synchronized (ds.lock2) {
                                    if (!ds.hasDetail())
                                        ds.lock2.wait();
                                    if (Arrays.stream(de).anyMatch(detailsEnum -> detailsEnum == ds.getDetailType())) {
                                        //FutureTask<Detail> df = new FutureTask(ds.getDetail());
                                        d.add(ds.getDetail());//df.get());
                                    }
                                    DetailsEnum[] de2 = de.clone();
                                    int a = 0;
                                    for (Detail detail : d)
                                        for (int f = 0; f < de2.length; f++) {
                                            if (de2[f] == detail.getType()) {
                                                de2[f] = null;
                                                a++;
                                            } else{
                                                    //System.out.println(ep.getDetailType().toString());
                                                synchronized (ds.getLock()) {
                                                    ds.getLock().notify();
                                                }

                                            }
                                        }
                                    if (a >= de.length) {
                                        ds.lock2.notifyAll();

                                        break FORBREAK;
                                    }
                                }
                            }
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }

                    }
                    else {
                        try {
                            while (!detailsStock.isNotFull())
                                lock7.wait();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }

                if(detailsStock.isNotFull(1)) {
                    System.out.println("МАШИНЫ: Added " + (detailsStock.getDetailsSize() + 1));
                    construct(d);
                }
            }
        },10,10);
    }

    private void construct(ArrayList<Detail> d) {
        try {
            //System.out.println();
            detailsStock.addStarted();
            System.out.println("СБОРКА: Начал собирать ласточку!" + Thread.currentThread().getName());
            //System.out.println();
            Thread.sleep(time);
            detailsStock.addDetail(new Detail(EngineProvider.id++,detailsEnum));
            //System.out.println();
            System.out.println("СБОРКА: Машина сделана!"  + Thread.currentThread().getName());
            detailsStock.removeStarted();
            //System.out.println();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public DetailsEnum getDetailType() {
        return detailsEnum;
    }

    @Override
    public Object getLock7() {
        return lock7;
    }

    @Override
    public String getName() {
        return detailsEnum.name()+"Constructor";
    }

    @Override
    public boolean isNotFull() {
        return d == null && started==0;
    }

    public boolean isNotFull(int a ) {
        return isNotFull();
    }

    @Override
    public int getDetailsSize() {
        return d==null ? 0 : 1;
    }

    @Override
    public void addDetail(Detail detail) {
        d = detail;
    }

    final Object lock = 1;
    @Override
    public Detail getDetail() throws InterruptedException {

        synchronized (lock) {
            while (d==null) lock.wait();
            Detail det = d;
            d = null;

            for(Stock ep : detailsStocks) {
                synchronized (ep.getLock()) {
                    ep.getLock().notify();
                }
            }

            return det;
        }
    }

    int started = 0;
    @Override
    public void addStarted() {
        started++;
    }

    @Override
    public void removeStarted() {

    }

    @Override
    public Object getLock() {
        return lock;
    }

    public int getStarted(){
        return started;
    }

    @Override
    public Detail[] getDetails() {
        return new Detail[] {d};
    }

    @Override
    public View[] getInput() {
        return detailsStock;
    }

    @Override
    public Models getModelType() {
        return Models.Constructor;
    }
}
