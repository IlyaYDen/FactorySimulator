package com.example.factorysimulation.models.controller;

import com.example.factorysimulation.models.prividers.Provider;
import com.example.factorysimulation.models.stock.DetailsStock;
import com.example.factorysimulation.models.stock.Stock;

import java.util.Timer;
import java.util.TimerTask;

public class DetailController {

    Stock stock;
    int less;
    public DetailController(Stock Stock, int less){
        this.stock = Stock;
        this.less = less;

    }
    boolean a = true;

    public void start(){
        Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if( (stock.getDetailsCount() < less) && a){
                    for(Provider ep : stock.getProviders()) {
                        //System.out.println(ep.getDetailType().toString());
                        synchronized (ep.getLock7()) {
                            ep.getLock7().notify();
                        }
                    }
                    a = false;
                } else {
                    a = true;
                }
            }
        },100,100);
    }
}
