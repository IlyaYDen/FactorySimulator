package com.example.factorysimulation.models.consumer;

public interface Consumer {
}
