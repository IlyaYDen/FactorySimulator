package com.example.factorysimulation.models.prividers;

import com.example.factorysimulation.models.details.Detail;
import com.example.factorysimulation.models.details.DetailsEnum;
import com.example.factorysimulation.models.stock.DetailsStock;
import com.example.factorysimulation.models.stock.Gettable;

import java.util.Timer;
import java.util.TimerTask;

public class EngineProvider implements Provider,Runnable {

    public static volatile int id;
    final Object lock = new Object();
    DetailsEnum name;
    int delay;
    //DetailsStock detailsStock;
    Gettable getter;

    public EngineProvider(DetailsEnum s, int i) {
        name = s;
        delay = i;
    }

    @Override
    public Object getLock7(){
        return lock;
    }


    @Override
    public void run() {

        System.out.println(getter.getName() + " start");
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                synchronized (lock) {
                    //System.out.println(detailsStock.name + " Provider adding: " + detailsStock.getDetailType().toString());
                    if (getter.isNotFull()) {

                        //synchronized (detailsStock.lock2){
                        //    detailsStock.lock2.notify();
                        //}
                    }
                    else {
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
                try {

                    Thread.sleep(delay);
                    System.out.println(getter.getName() + " added " + (getter.getDetailsSize()+1));
                    getter.addDetail(new Detail(id++,name));

                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                synchronized (getter.getLock()){
                    getter.getLock().notify();
                }
            }
        }, delay, delay);
    }

    public void start(Gettable gettable) throws InterruptedException {
        //System.out.println(detailsStock.name + " EngineProvider starts: " + detailsStock.getDetailType().toString());
        this.getter = gettable;
        Thread thread = new Thread(this);
        thread.start();
    }

    @Override
    public DetailsEnum getDetailType() {
        return name;
    }
}
