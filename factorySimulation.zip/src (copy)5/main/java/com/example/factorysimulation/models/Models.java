package com.example.factorysimulation.models;

public enum Models {
    Constructor("Constructor"),
    Consumer("Dealer"),
    Controller("Controller"),
    Provider("Provider"),
    Stock("Stock"),
    ;

    Models(String s) {
    }
}
