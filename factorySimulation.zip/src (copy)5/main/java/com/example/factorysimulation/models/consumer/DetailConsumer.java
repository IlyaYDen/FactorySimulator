package com.example.factorysimulation.models.consumer;

import com.example.factorysimulation.models.prividers.Provider;
import com.example.factorysimulation.models.stock.Gettable;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DetailConsumer implements Consumer, Runnable {

    Gettable gettable;
    int delay;
    int workers;
    public DetailConsumer(Gettable gettable, int delay, int workers) {
        this.gettable = gettable;
        this.delay = delay;
        this.workers = workers;
    }

    public void start() {
        ExecutorService tp = Executors.newFixedThreadPool(workers);
        for(int a = 0 ; a < workers ; a ++)
            tp.execute(this);
    }

    @Override
    public void run() {

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    System.out.println("Consumer забрал ласточку " + gettable.getDetailsSize());
                    gettable.getDetail();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },delay,delay);
    }

}
